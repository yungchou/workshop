# Description

Provides a mechanism to configure and manage Windows services.
This resource works on Nano Server.
