# Description

Provides a mechanism to manage local groups on the target node.
This resource works on Nano Server.
